package exception;

public class OpcionNoValidaException extends Exception{
}
