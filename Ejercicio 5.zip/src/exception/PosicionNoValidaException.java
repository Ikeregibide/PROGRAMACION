package exception;

public class PosicionNoValidaException extends Exception{
}
