package exception;

public class ValorNoValidoException extends Exception{
}
