package exceptions;

public class CodigoNoValidoException extends Exception{
}
