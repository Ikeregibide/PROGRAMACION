package Excepciones;

public class ValorNoValidoException extends Exception{
}
